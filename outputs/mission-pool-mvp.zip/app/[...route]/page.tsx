import MissionPoolApp from "../components/MissionPoolApp";

export default function CatchAllPage() {
  return <MissionPoolApp />;
}
